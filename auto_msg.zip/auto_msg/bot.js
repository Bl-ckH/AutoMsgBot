const Discord = require('discord.js');
const config = require('./config.json');

const client = new Discord.Client({
  intents: [
    "GUILDS",
    "GUILD_MESSAGES",
    "GUILD_MESSAGE_TYPING"
  ]
});
  
client.on("ready", () => {
  console.log(`${client.user.username} ist bereit!`);
  client.user.setPresence({
    activities: [{ name: config.status, type: Discord.Constants.ActivityTypes.PLAYING }],
    status: "online"
  });

  const channel1 = client.channels.cache.get(config.channel);
  
  setInterval(() => {
    const message = config.Nachricht;
    channel1.send(message);
  }, config.zeit);
});

client.login(config.token);